-- Qazaqsha Speaking: онлайн-настройка Supabase
-- ВАЖНО: этот SQL запускается в Supabase -> Редактор SQL.

-- 1. Создаём/обновляем профиль автоматически после регистрации ученика.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, grade, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', 'Ученик'),
    coalesce(new.raw_user_meta_data->>'grade', '10-сынып'),
    'student'
  )
  on conflict (id) do update
  set full_name = excluded.full_name,
      grade = excluded.grade;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- 2. Функция проверки: является ли вошедший пользователь учителем.
create or replace function public.is_teacher()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'teacher'
  );
$$;

-- 3. Учитель может видеть всех учеников.
create policy "teacher_view_all_profiles"
on public.profiles
for select
to authenticated
using (public.is_teacher());

-- 4. Учитель может видеть все результаты.
create policy "teacher_view_all_results"
on public.speaking_results
for select
to authenticated
using (public.is_teacher());

-- 5. Учитель может видеть все отзывы.
create policy "teacher_view_all_feedback"
on public.feedback
for select
to authenticated
using (public.is_teacher());

-- 6. ПОСЛЕ регистрации своего аккаунта учителя:
-- замените email на свой и выполните эту строку ОДИН РАЗ.
-- update public.profiles p
-- set role = 'teacher'
-- from auth.users u
-- where p.id = u.id and u.email = 'ВАШ_EMAIL';
